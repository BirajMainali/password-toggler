# Password viewer(show/hide)
_Password viewer extension for browsers like firefox,chrome etc._

![image](https://user-images.githubusercontent.com/71131016/174945894-6b95f97d-fe0f-481a-9674-4ff9cbe8d8a0.png)


![image](https://user-images.githubusercontent.com/71131016/174946242-a2fbc703-0aec-48ef-90b5-2ebbaf8d17f7.png)

